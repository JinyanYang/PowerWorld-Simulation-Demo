# Contributing

Thanks for your interest! This repository primarily serves as an academic portfolio.
If you spot an issue or would like to suggest improvements, feel free to open an issue or a pull request.